import { ExpoConfig, ConfigContext } from "expo/config";

/**
 * App config reads secrets/URLs from environment variables only.
 * Never hard-code the Supabase URL/anon key here.
 * EXPO_PUBLIC_* vars are safe to ship in the client bundle (they are
 * public by design — the anon key's power is bounded entirely by
 * Postgres Row Level Security, not by keeping the key secret).
 */
export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: "Motoraconect",
  slug: "motoraconect",
  version: "0.1.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  scheme: "motoraconect",
  userInterfaceStyle: "automatic",
  splash: {
    backgroundColor: "#0B1F3A",
  },
  assetBundlePatterns: ["**/*"],
  ios: {
    supportsTablet: true,
    bundleIdentifier: "com.motoraconect.app",
  },
  android: {
    package: "com.motoraconect.app",
    adaptiveIcon: {
      backgroundColor: "#0B1F3A",
    },
  },
  web: {
    bundler: "metro",
  },
  plugins: ["expo-router"],
  extra: {
    supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL,
    supabaseAnonKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,
  },
});
