import React from "react";
import { Pressable, PressableProps, StyleSheet, ActivityIndicator } from "react-native";
import { useTheme } from "@/theme/ThemeProvider";
import { AppText } from "./AppText";

interface ButtonProps extends PressableProps {
  label: string;
  variant?: "primary" | "secondary" | "ghost";
  loading?: boolean;
}

/** Primary button primitive. Amber accent reserved for the "primary" variant only. */
export function Button({ label, variant = "primary", loading, style, disabled, ...rest }: ButtonProps) {
  const theme = useTheme();

  const backgroundColor =
    variant === "primary" ? theme.colors.accent : variant === "secondary" ? theme.colors.surface : "transparent";
  const textColor = variant === "primary" ? theme.colors.textPrimary : theme.colors.primary;
  const borderColor = variant === "ghost" ? theme.colors.border : "transparent";

  return (
    <Pressable
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.base,
        {
          backgroundColor,
          borderColor,
          borderWidth: variant === "ghost" ? 1 : 0,
          opacity: pressed || disabled ? 0.7 : 1,
          paddingVertical: theme.spacing.sm + 4,
          paddingHorizontal: theme.spacing.md,
          borderRadius: theme.radius.md,
        },
        style as any,
      ]}
      {...rest}
    >
      {loading ? <ActivityIndicator color={textColor} /> : <AppText variant="body" color={textColor} style={{ fontWeight: "600", textAlign: "center" }}>{label}</AppText>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    alignItems: "center",
    justifyContent: "center",
  },
});
