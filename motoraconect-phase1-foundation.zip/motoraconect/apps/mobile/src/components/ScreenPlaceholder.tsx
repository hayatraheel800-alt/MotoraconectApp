import React from "react";
import { View, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useTheme } from "@/theme/ThemeProvider";
import { AppText } from "./AppText";

interface Props {
  title: string;
  description: string;
  /** True if this screen has no real data/backend wiring yet. */
  mocked?: boolean;
}

/**
 * Placeholder for screens whose real implementation belongs to a later
 * phase. Per project rule §69/§19: never present a static screen as if
 * it were backed by real data — every unimplemented screen must say so.
 */
export function ScreenPlaceholder({ title, description, mocked = true }: Props) {
  const theme = useTheme();
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={{ padding: theme.spacing.lg }}>
        <AppText variant="title">{title}</AppText>
        <AppText variant="body" color={theme.colors.textSecondary} style={{ marginTop: theme.spacing.sm }}>
          {description}
        </AppText>
        {mocked && (
          <View
            style={{
              marginTop: theme.spacing.lg,
              backgroundColor: theme.colors.surface,
              borderRadius: theme.radius.md,
              padding: theme.spacing.sm,
              alignSelf: "flex-start",
            }}
          >
            <AppText variant="caption" color={theme.colors.textSecondary}>
              MOCKED FOR DEVELOPMENT — this screen is not yet connected to real data.
            </AppText>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});
