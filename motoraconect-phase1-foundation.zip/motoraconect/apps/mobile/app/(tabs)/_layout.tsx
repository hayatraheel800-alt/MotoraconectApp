import React from "react";
import { Tabs } from "expo-router";
import { useTheme } from "@/theme/ThemeProvider";

/**
 * Primary bottom-tab navigation — HOME, VEHICLES, SELL, SERVICES, PROFILE
 * per architecture doc §6/§12. Every other screen in the app is reachable
 * from within these five, rather than adding more tabs later.
 *
 * Using text labels instead of an icon library for Phase 1 to avoid
 * pulling in a dependency before it's needed; swap in @expo/vector-icons
 * when Phase 3 gives these tabs real content worth polishing.
 */
export default function TabsLayout() {
  const theme = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textSecondary,
        tabBarStyle: { borderTopColor: theme.colors.border },
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Home" }} />
      <Tabs.Screen name="vehicles/index" options={{ title: "Vehicles" }} />
      <Tabs.Screen name="sell/index" options={{ title: "Sell" }} />
      <Tabs.Screen name="services/index" options={{ title: "Services" }} />
      <Tabs.Screen name="profile/index" options={{ title: "Profile" }} />
    </Tabs>
  );
}
