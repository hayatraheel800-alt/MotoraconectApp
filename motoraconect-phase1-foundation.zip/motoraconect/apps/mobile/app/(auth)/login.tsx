import React, { useState } from "react";
import { View, TextInput, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Link } from "expo-router";
import { useTheme } from "@/theme/ThemeProvider";
import { AppText } from "@/components/AppText";
import { Button } from "@/components/Button";

/**
 * UI scaffold only. Real Supabase auth (supabase.auth.signInWithPassword,
 * error handling, session redirect) is built in Phase 2 — see
 * docs/architecture. Submitting this form does nothing yet.
 */
export default function LoginScreen() {
  const theme = useTheme();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={{ padding: theme.spacing.lg }}>
        <AppText variant="display" style={{ marginBottom: theme.spacing.xs }}>Welcome back</AppText>
        <AppText variant="body" color={theme.colors.textSecondary} style={{ marginBottom: theme.spacing.lg }}>
          Log in to Motoraconect
        </AppText>

        <TextInput
          placeholder="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          style={[styles.input, { borderColor: theme.colors.border }]}
        />
        <TextInput
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          style={[styles.input, { borderColor: theme.colors.border, marginTop: theme.spacing.sm }]}
        />

        <View style={{ marginTop: theme.spacing.lg }}>
          <Button
            label="Log in"
            disabled
            onPress={() => {
              // Intentionally not wired yet — Phase 2 implements real auth.
            }}
          />
        </View>
        <AppText variant="caption" color={theme.colors.textSecondary} style={{ marginTop: theme.spacing.sm }}>
          Login is not yet functional (MOCKED FOR DEVELOPMENT) — implemented in Phase 2.
        </AppText>

        <Link href="/(auth)/signup" style={{ marginTop: theme.spacing.lg }}>
          <AppText variant="body" color={theme.colors.info}>Don't have an account? Sign up</AppText>
        </Link>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
  },
});
