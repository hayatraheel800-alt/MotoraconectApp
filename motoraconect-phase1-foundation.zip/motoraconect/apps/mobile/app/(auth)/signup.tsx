import React, { useState } from "react";
import { View, TextInput, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Link } from "expo-router";
import { useTheme } from "@/theme/ThemeProvider";
import { AppText } from "@/components/AppText";
import { Button } from "@/components/Button";

/** UI scaffold only — see (auth)/login.tsx. Real signup ships in Phase 2. */
export default function SignupScreen() {
  const theme = useTheme();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={{ padding: theme.spacing.lg }}>
        <AppText variant="display" style={{ marginBottom: theme.spacing.xs }}>Create account</AppText>
        <AppText variant="body" color={theme.colors.textSecondary} style={{ marginBottom: theme.spacing.lg }}>
          Join Motoraconect
        </AppText>

        <TextInput placeholder="Full name" value={name} onChangeText={setName} style={[styles.input, { borderColor: theme.colors.border }]} />
        <TextInput
          placeholder="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          style={[styles.input, { borderColor: theme.colors.border, marginTop: theme.spacing.sm }]}
        />
        <TextInput
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          style={[styles.input, { borderColor: theme.colors.border, marginTop: theme.spacing.sm }]}
        />

        <View style={{ marginTop: theme.spacing.lg }}>
          <Button label="Create account" disabled onPress={() => {}} />
        </View>
        <AppText variant="caption" color={theme.colors.textSecondary} style={{ marginTop: theme.spacing.sm }}>
          Signup is not yet functional (MOCKED FOR DEVELOPMENT) — implemented in Phase 2.
        </AppText>

        <Link href="/(auth)/login" style={{ marginTop: theme.spacing.lg }}>
          <AppText variant="body" color={theme.colors.info}>Already have an account? Log in</AppText>
        </Link>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
  },
});
