import React from "react";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ThemeProvider } from "@/theme/ThemeProvider";

/**
 * Root layout. Phase 1 scope: just theming + a plain Stack around the
 * (auth) and (tabs) route groups. Real auth-gating (redirect signed-out
 * users away from (tabs), redirect signed-in users away from (auth)) is
 * Phase 2 work, once supabase.auth session handling actually exists.
 */
export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="(auth)" />
        </Stack>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
