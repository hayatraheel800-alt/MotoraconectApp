import React from "react";
import { Link, Stack } from "expo-router";
import { View, StyleSheet } from "react-native";
import { AppText } from "@/components/AppText";

export default function NotFoundScreen() {
  return (
    <>
      <Stack.Screen options={{ title: "Not found" }} />
      <View style={styles.container}>
        <AppText variant="title">This screen doesn't exist.</AppText>
        <Link href="/" style={styles.link}>
          <AppText variant="body" color="#2563A6">Go to home screen</AppText>
        </Link>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center", padding: 20 },
  link: { marginTop: 16, paddingVertical: 15 },
});
