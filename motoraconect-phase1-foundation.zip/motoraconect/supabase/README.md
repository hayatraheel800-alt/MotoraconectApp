# Supabase

This project is not yet linked to a Supabase project, and no migrations exist yet
by design — Phase 1 is app-foundation only (§7 of the master prompt explicitly
excludes marketplace/data-model work from Phase 1).

## What's here now
- `migrations/` — empty. The first migrations (`profiles`, `roles`, `user_roles`,
  and their RLS policies) are created in Phase 2.
- `functions/` — empty. Edge Functions are added starting whichever phase first
  needs a secret-holding operation (earliest candidate: Phase 4, auction analysis).

## Setting up a project (do this before Phase 2)
1. Create a free project at https://supabase.com.
2. Copy the Project URL and anon public key into `apps/mobile/.env`
   (see `apps/mobile/.env.example`).
3. Install the Supabase CLI locally and run `supabase link` against your project
   before Phase 2 starts writing migrations, so they can be applied with
   `supabase db push`.

## Rules for every future migration (see docs/architecture §36–37)
- RLS is enabled in the same migration that creates the table — never a follow-up.
- No destructive migration (drop table/column) runs without explicit confirmation.
- Money columns use `numeric(14,2)` with a paired `currency` column — never `float`.
