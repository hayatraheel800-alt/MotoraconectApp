/**
 * Shared TypeScript types for Motoraconect.
 *
 * These are hand-written for Phase 1 scaffolding only. From Phase 2 onward,
 * database row types should be generated from Supabase migrations
 * (`supabase gen types typescript`) rather than hand-maintained, to avoid
 * drift between the schema and the app. Hand-written domain enums below
 * mirror planned DB lookup tables/check constraints — they are a reference
 * for the client, not the source of truth (the database is).
 */

// ---- User roles (mirrors future `roles` table) ----
export type UserRole =
  | "USER"
  | "BUYER"
  | "SELLER"
  | "DEALER"
  | "CONSULTANT"
  | "MODERATOR"
  | "ADMIN"
  | "SUPER_ADMIN";

// ---- Vehicle listing status (mirrors future `vehicles.status` constraint) ----
export type VehicleStatus =
  | "DRAFT"
  | "PENDING_REVIEW"
  | "ACTIVE"
  | "RESERVED"
  | "SOLD"
  | "EXPIRED"
  | "REJECTED"
  | "SUSPENDED";

// ---- Confidence levels for auction-sheet / AI-derived data ----
export type ConfidenceLevel = "HIGH" | "MEDIUM" | "LOW";

// ---- How a piece of data was obtained — required on auction report fields ----
export type DataProvenance =
  | "DETECTED"
  | "INTERPRETED"
  | "USER_PROVIDED"
  | "ESTIMATED"
  | "UNVERIFIED";

// ---- Generic result shape returned by every packages/api function ----
export type ServiceResult<T> =
  | { data: T; error: null }
  | { data: null; error: ServiceError };

export interface ServiceError {
  code: string;
  message: string;
  /** Safe to show the user. Never leak raw Postgres/driver errors. */
  userMessage: string;
}
